from binance.client import Client
from bot_config import BINANCE_API_KEY, BINANCE_SECRET
from sheets_helper import log_to_sheet

client = Client(BINANCE_API_KEY, BINANCE_SECRET)

SYMBOL = 'BTCUSDT'
BUY_PRICE = 30000
SELL_PRICE = 31000
AMOUNT = 0.001

def run_trade_bot():
    price = float(client.get_symbol_ticker(symbol=SYMBOL)['price'])
    result = {"price": price, "action": "Hold"}

    if price <= BUY_PRICE:
        client.order_market_buy(symbol=SYMBOL, quantity=AMOUNT)
        result["action"] = "BUY"
    elif price >= SELL_PRICE:
        client.order_market_sell(symbol=SYMBOL, quantity=AMOUNT)
        result["action"] = "SELL"

    log_to_sheet(["Trade", SYMBOL, price, result["action"]])
    return result