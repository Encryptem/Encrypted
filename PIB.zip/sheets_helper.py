import gspread
from oauth2client.service_account import ServiceAccountCredentials
from datetime import datetime
from bot_config import GOOGLE_SHEET_NAME

def get_sheet():
    scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
    creds = ServiceAccountCredentials.from_json_keyfile_name("credentials.json", scope)
    client = gspread.authorize(creds)
    sheet = client.open(GOOGLE_SHEET_NAME).sheet1
    return sheet

def log_to_sheet(data):
    sheet = get_sheet()
    sheet.append_row([datetime.now().strftime('%Y-%m-%d %H:%M:%S')] + data)