from flask import Flask, jsonify
from income_bot import run_income_tracker
from trade_bot import run_trade_bot

app = Flask(__name__)

@app.route("/")
def home():
    return "Passive Income + Trading Bot Dashboard"

@app.route("/run/income")
def run_income():
    result = run_income_tracker()
    return jsonify(result)

@app.route("/run/trade")
def run_trade():
    result = run_trade_bot()
    return jsonify(result)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)