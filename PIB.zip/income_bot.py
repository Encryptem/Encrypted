import requests
from sheets_helper import log_to_sheet
from bot_config import DIMO_WALLET_ADDRESS, GRASS_API_KEY

def get_dimo_earnings():
    url = f"https://api.dimo.zone/wallet/{DIMO_WALLET_ADDRESS}/rewards"
    response = requests.get(url)
    return response.json().get('total_rewards', 0)

def get_grass_earnings():
    url = "https://api.getgrass.io/earnings"
    headers = {"Authorization": f"Bearer {GRASS_API_KEY}"}
    response = requests.get(url, headers=headers)
    return response.json().get("total_earned", 0)

def run_income_tracker():
    dimo = get_dimo_earnings()
    grass = get_grass_earnings()
    total = dimo + grass
    log_to_sheet(["DIMO", dimo])
    log_to_sheet(["Grass", grass])
    log_to_sheet(["Total", total])
    return {"dimo": dimo, "grass": grass, "total": total}